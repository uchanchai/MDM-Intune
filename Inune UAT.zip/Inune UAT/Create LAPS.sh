#!/bin/bash


# Create LAPS admin on macOS Device
sysadminctl -addUser lapsadmin -fullName "LAPS Admin" -password "TempPass123!" -admin

#!/bin/bash



## Ask macOSLAPS to write out the current password to the system keychain
/usr/local/laps/macOSLAPS -getPassword
SERVICE_NAME=$(sudo /bin/cat /var/root/.GeneratedLAPSServiceName)
SERVICE_NAME=$(echo "$SERVICE_NAME" | sed 's/%//g')
CURRENT_PASSWORD=$(sudo /usr/bin/security find-generic-password -s "$SERVICE_NAME" -w)
CURRENT_EXPIRATION=$(sudo /usr/bin/security find-generic-password -s "$SERVICE_NAME" | /usr/bin/grep -Eo "\d{4}-\d{2}-\d{2}.*\d")

## Test $current_password to ensure there is a value
if [ -z "$CURRENT_PASSWORD" ]
then
    echo "ERROR: failed to retrieve password"
    exit 1
else
    echo "Password: $CURRENT_PASSWORD | Expiration: $CURRENT_EXPIRATION"
    ## Run macOSLAPS a second time to remove the password export entry from the system keychain
    # echo "Clearing the temporarily stored password from the keychain"
    /usr/local/laps/macOSLAPS > /dev/null
fi


# Output the password
echo "The password is: $CURRENT_PASSWORD"